# Alterações realizadas — My Tec. Odonto

## Imagens substituídas

### 1. Foto do Técnico (`/tecnico.png`)
- **Onde aparece:**
  - `HeroSection.tsx` — card flutuante no canto direito
  - `AboutSection.tsx` — foto principal da seção "Nossa História"
- **Arquivo:** `client/public/tecnico.png`

---

## Novo Catálogo PDF

### Arquivo adicionado: `CatalogPdfSection.tsx`
Substitui o `CatalogSection.tsx` antigo por um **visualizador de catálogo em páginas**.

**Funcionalidades:**
- Visualização em dupla página (estilo livro)
- Navegação por botões Anterior/Próximo
- Campo para ir direto à página desejada
- Atalhos rápidos por intervalo (Pág 1–10, 11–20, etc.)
- Miniaturas de navegação
- **Lightbox** ao clicar em qualquer página (amplia a imagem com setas de navegação)
- Botão para **baixar o PDF completo**
- Botão direto para **WhatsApp**
- Banner CTA com parcelamento em 6x

### Imagens do catálogo
- **66 páginas** convertidas em JPG e salvas em `client/public/catalogo/`
- PDF original salvo em `client/public/catalogo/catalogo-primos-marco-2026.pdf`

---

## Como integrar no App.tsx

Substitua a importação do `CatalogSection` pelo novo componente:

```tsx
// Antes:
import CatalogSection from '@/components/sections/CatalogSection';

// Depois:
import CatalogSection from '@/components/sections/CatalogPdfSection';
```

O `id="catalogo"` foi mantido, então todos os links de navegação funcionam normalmente.

---

## Estrutura de arquivos adicionados

```
client/
├── public/
│   ├── tecnico.png                          ← foto do técnico
│   └── catalogo/
│       ├── catalogo-primos-marco-2026.pdf   ← PDF original para download
│       ├── page_01.jpg                      ← páginas do catálogo
│       ├── page_02.jpg
│       ├── ...
│       └── page_66.jpg
└── src/
    └── components/
        └── sections/
            └── CatalogPdfSection.tsx        ← novo visualizador de catálogo
```
