/**
 * AboutSection — My Tec. Odonto Soluções
 * História da empresa com imagem e destaques
 */

import { Award, MapPin, Globe, Calendar } from 'lucide-react';

const CDN = 'https://d2xsxph8kpxj0f.cloudfront.net/310519663421337620/KxGQz48AK3ognB3Cs5eo6C';

const milestones = [
  { icon: Calendar, label: '2019', sublabel: 'Fundação' },
  { icon: MapPin, label: 'MA', sublabel: 'Sede em São Luís' },
  { icon: Globe, label: 'BR', sublabel: 'Cobertura Nacional' },
  { icon: Award, label: '98%', sublabel: 'Satisfação' },
];

export default function AboutSection() {
  return (
    <section id="sobre" className="py-20 lg:py-28 bg-white">
      <div className="container">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          {/* Image side */}
          <div className="relative order-2 lg:order-1">
            <div className="relative rounded-2xl overflow-hidden shadow-2xl">
              <img
                src="/tecnico.png"
                alt="Técnico My Tec. Odonto realizando manutenção"
                className="w-full h-[420px] object-cover object-top"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#0D1B3E]/60 to-transparent" />
              <div className="absolute bottom-6 left-6 right-6">
                <div className="bg-white/10 backdrop-blur-md border border-white/20 rounded-xl p-4">
                  <p className="text-white/90 text-sm italic leading-relaxed">
                    "Nossa missão é garantir que nenhum consultório pare por falta de peças ou equipamentos."
                  </p>
                  <p className="text-[#10B981] font-bold text-sm mt-2">— Fundadores My Tec.</p>
                </div>
              </div>
            </div>

            {/* Floating badge */}
            <div className="absolute -top-4 -right-4 bg-[#1A3A6B] text-white rounded-2xl p-4 shadow-xl hidden lg:block">
              <p className="font-black text-3xl leading-none" style={{ fontFamily: 'Barlow Condensed, sans-serif' }}>+5K</p>
              <p className="text-blue-200 text-xs mt-1">Peças vendidas</p>
            </div>
          </div>

          {/* Text side */}
          <div className="order-1 lg:order-2">
            <div className="inline-flex items-center gap-2 bg-blue-50 text-[#1A3A6B] rounded-full px-4 py-1.5 mb-5 text-sm font-semibold">
              <Award size={14} />
              Nossa História
            </div>

            <h2 className="text-3xl lg:text-4xl font-black text-gray-900 leading-tight mb-5">
              Fundada em 2019 com uma missão clara:{' '}
              <span className="text-[#1A3A6B]">revolucionar o suporte técnico odontológico</span>
            </h2>

            <div className="space-y-4 text-gray-600 leading-relaxed">
              <p>
                A <strong className="text-gray-800">My Tec. Odonto Soluções Ltda</strong> foi fundada em{' '}
                <strong className="text-gray-800">09 de dezembro de 2019</strong>, nasceu da percepção de que o mercado
                odontológico brasileiro carecia de um parceiro técnico verdadeiramente completo.
              </p>
              <p>
                Percebemos que dentistas e clínicas enfrentavam dificuldades para encontrar peças de reposição qualificadas,
                alugar equipamentos modernos sem burocracia e ter acesso a manutenção preventiva eficiente.
              </p>
              <p>
                Com sede em <strong className="text-gray-800">São Luís, Maranhão</strong>, começamos como uma pequena
                assistência técnica especializada em autoclaves e ultrassons. Rapidamente, expandimos nossa atuação para
                atender todo o território nacional.
              </p>
            </div>

            {/* Milestones */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mt-8">
              {milestones.map(({ icon: Icon, label, sublabel }) => (
                <div key={label} className="text-center p-4 bg-gray-50 rounded-xl border border-gray-100 hover:border-[#1A3A6B]/20 hover:bg-blue-50/50 transition-all">
                  <Icon size={20} className="text-[#1A3A6B] mx-auto mb-2" />
                  <p className="font-black text-[#1A3A6B] text-xl" style={{ fontFamily: 'Barlow Condensed, sans-serif' }}>{label}</p>
                  <p className="text-gray-500 text-xs mt-0.5">{sublabel}</p>
                </div>
              ))}
            </div>

            {/* Authorized Service Section */}
            <div className="mt-10 p-6 bg-gradient-to-r from-blue-50 to-emerald-50 rounded-2xl border border-blue-100">
              <h3 className="font-bold text-gray-900 mb-4 text-lg">Assistência Técnica Autorizada</h3>
              <p className="text-gray-700 text-sm mb-4">Somos assistência técnica autorizada de equipamentos odontológicos, prótese dentária e hospitalares das seguintes marcas:</p>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {['NSK', 'Driller', 'Dentemed', 'Bioart', 'Dentsply Sirona', 'Stermax', 'Medpej', 'EDG', 'KOTA', 'Protecni', 'Sanders Medical', 'Sismatec Focos'].map(brand => (
                  <div key={brand} className="text-sm font-semibold text-[#1A3A6B] bg-white/60 px-3 py-2 rounded-lg text-center">{brand}</div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
