/**
 * CatalogSection — My Tec. Odonto Soluções
 * Catálogo de peças com filtros por categoria, busca e adição ao carrinho
 */

import { useState, useMemo } from 'react';
import { Search, ShoppingCart, MessageCircle, Package, Filter, CheckCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useCart } from '@/contexts/CartContext';
import { products, categoryFilters } from '@/lib/products';
import { toast } from 'sonner';

const statusConfig = {
  'em-estoque': { label: 'Em estoque', color: 'bg-[#10B981] text-white' },
  'sob-encomenda': { label: 'Sob encomenda', color: 'bg-amber-500 text-white' },
  'ultimos': { label: 'Últimas unidades', color: 'bg-red-500 text-white' },
};

export default function CatalogSection() {
  const [activeCategory, setActiveCategory] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [addedIds, setAddedIds] = useState<Set<string>>(new Set());
  const { addItem } = useCart();

  const filtered = useMemo(() => {
    return products.filter(p => {
      const matchCat = activeCategory === 'all' || p.category === activeCategory;
      const q = searchQuery.toLowerCase();
      const matchSearch = !q || p.name.toLowerCase().includes(q) || p.code.toLowerCase().includes(q) || p.categoryLabel.toLowerCase().includes(q);
      return matchCat && matchSearch;
    });
  }, [activeCategory, searchQuery]);

  const handleAddToCart = (product: typeof products[0]) => {
    addItem({
      id: product.id,
      name: product.name,
      code: product.code,
      category: product.categoryLabel,
      price: product.price,
      image: product.image,
    });
    setAddedIds(prev => { const next = new Set(prev); next.add(product.id); return next; });
    toast.success(`${product.name.slice(0, 40)}... adicionado à lista!`, {
      description: 'Abra sua lista para enviar via WhatsApp.',
      duration: 3000,
    });
    setTimeout(() => {
      setAddedIds(prev => {
        const next = new Set(prev);
        next.delete(product.id);
        return next;
      });
    }, 2000);
  };

  const handleWhatsApp = (product: typeof products[0]) => {
    const msg = encodeURIComponent(
      `Olá! Tenho interesse no produto:\n\n*${product.name}*\nCódigo: ${product.code}\nCategoria: ${product.categoryLabel}\n\nPoderia me informar disponibilidade e valor? Obrigado!`
    );
    window.open(`https://wa.me/5598981905646?text=${msg}`, '_blank');
  };

  return (
    <section id="catalogo" className="py-20 lg:py-28 bg-white">
      <div className="container">
        {/* Header */}
        <div className="text-center mb-10">
          <div className="inline-flex items-center gap-2 bg-blue-50 text-[#1A3A6B] rounded-full px-4 py-1.5 mb-4 text-sm font-semibold">
            <Package size={14} />
            Catálogo de Peças
          </div>
          <h2 className="text-3xl lg:text-4xl font-black text-gray-900 mb-3">
            Encontre rapidamente o que precisa{' '}
            <span className="text-[#1A3A6B]">para seu equipamento</span>
          </h2>
          <p className="text-gray-500 max-w-lg mx-auto">
            Mais de 5.000 itens em estoque. Adicione à sua lista e envie via WhatsApp para receber orçamento.
          </p>
        </div>

        {/* Search + Filters */}
        <div className="flex flex-col sm:flex-row gap-4 mb-8">
          <div className="relative flex-1">
            <Search size={18} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400" />
            <Input
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              placeholder="Buscar por nome, modelo ou código..."
              className="pl-10 h-11 border-gray-200 focus:border-[#1A3A6B] rounded-xl"
            />
          </div>
          <div className="flex items-center gap-2 overflow-x-auto pb-1 sm:pb-0">
            <Filter size={16} className="text-gray-400 flex-shrink-0" />
            {categoryFilters.map(f => (
              <button
                key={f.value}
                onClick={() => setActiveCategory(f.value)}
                className={`flex-shrink-0 px-4 py-2 rounded-xl text-sm font-semibold transition-all duration-200 ${
                  activeCategory === f.value
                    ? 'bg-[#1A3A6B] text-white shadow-md'
                    : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                }`}
              >
                {f.label}
              </button>
            ))}
          </div>
        </div>

        {/* Products Grid */}
        {filtered.length === 0 ? (
          <div className="text-center py-16">
            <Package size={48} className="text-gray-300 mx-auto mb-4" />
            <p className="text-gray-500 font-semibold text-lg">Nenhum produto encontrado</p>
            <p className="text-gray-400 text-sm mt-1">Tente outro termo de busca ou categoria</p>
            <Button
              className="mt-4 bg-[#25D366] hover:bg-[#1fba59] text-white gap-2"
              onClick={() => window.open('https://wa.me/5598981905646?text=Olá! Preciso de uma peça específica que não encontrei no catálogo. Pode me ajudar?', '_blank')}
            >
              <MessageCircle size={16} />
              Solicitar Peça Específica
            </Button>
          </div>
        ) : (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
            {filtered.map(product => {
              const status = statusConfig[product.status];
              const isAdded = addedIds.has(product.id);
              return (
                <div key={product.id} className="product-card bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden flex flex-col">
                  {/* Image */}
                  <div className="relative h-44 bg-gray-50 overflow-hidden">
                    <img
                      src={product.image}
                      alt={product.name}
                      className="w-full h-full object-cover transition-transform duration-300 hover:scale-105"
                    />
                    <div className={`absolute top-2.5 left-2.5 text-xs font-bold px-2.5 py-1 rounded-full ${status.color}`}>
                      {status.label}
                    </div>
                    <div className="absolute top-2.5 right-2.5 bg-white/90 backdrop-blur-sm text-[#1A3A6B] text-xs font-bold px-2 py-1 rounded-lg border border-blue-100">
                      {product.categoryLabel}
                    </div>
                  </div>

                  {/* Content */}
                  <div className="p-4 flex flex-col flex-1">
                    <p className="text-xs text-gray-400 font-medium mb-1">Cód: {product.code}</p>
                    <h3 className="font-bold text-gray-800 text-sm leading-snug mb-2 line-clamp-2 flex-1">{product.name}</h3>
                    {product.compatibility && (
                      <p className="text-xs text-gray-500 mb-3 line-clamp-1">
                        <span className="font-medium">Compatível:</span> {product.compatibility}
                      </p>
                    )}
                    <p className="text-[#1A3A6B] font-black text-base mb-4">{product.price}</p>

                    {/* Actions */}
                    <div className="flex gap-2">
                      <Button
                        onClick={() => handleAddToCart(product)}
                        className={`flex-1 text-xs font-bold gap-1.5 rounded-xl transition-all duration-200 ${
                          isAdded
                            ? 'bg-[#10B981] hover:bg-[#0ea572] text-white'
                            : 'bg-[#1A3A6B] hover:bg-[#152f58] text-white'
                        }`}
                      >
                        {isAdded ? (
                          <>
                            <CheckCircle size={14} />
                            Adicionado
                          </>
                        ) : (
                          <>
                            <ShoppingCart size={14} />
                            Adicionar
                          </>
                        )}
                      </Button>
                      <button
                        onClick={() => handleWhatsApp(product)}
                        className="w-10 h-9 flex items-center justify-center bg-[#25D366] hover:bg-[#1fba59] text-white rounded-xl transition-colors flex-shrink-0"
                        title="Solicitar via WhatsApp"
                      >
                        <svg viewBox="0 0 24 24" className="w-4 h-4 fill-current"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* CTA to request unlisted parts */}
        <div className="mt-10 text-center">
          <div className="inline-flex flex-col sm:flex-row items-center gap-4 bg-blue-50 border border-blue-100 rounded-2xl px-6 py-5">
            <div className="text-left">
              <p className="font-bold text-gray-800">Não encontrou o que precisa?</p>
              <p className="text-gray-500 text-sm">Nossa equipe pode localizar qualquer peça para seu equipamento.</p>
            </div>
            <Button
              onClick={() => window.open('https://wa.me/5598981905646?text=Olá! Preciso de uma peça específica que não encontrei no catálogo. Pode me ajudar?', '_blank')}
              className="flex-shrink-0 bg-[#25D366] hover:bg-[#1fba59] text-white font-bold gap-2 rounded-xl"
            >
              <MessageCircle size={16} />
              Solicitar via WhatsApp
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
}
