/**
 * ContactSection — My Tec. Odonto Soluções
 * Informações de contato, localização e horários
 */

import { MapPin, Phone, Mail, Clock, ExternalLink } from 'lucide-react';

const contactInfo = [
  {
    icon: MapPin,
    title: 'Endereço',
    lines: ['Rua Quéops, nº 12, Sala 602', 'Edif. Executive Center, Renascença', 'São Luís - MA, CEP: 65075-800'],
    action: { label: 'Como Chegar', href: 'https://maps.google.com/?q=Rua+Quéops+12+Renascença+São+Luís+MA' },
  },
  {
    icon: Phone,
    title: 'Telefone / WhatsApp',
    lines: ['(98) 98190-5646'],
    action: { label: 'Ligar Agora', href: 'tel:+5598981905646' },
  },
  {
    icon: Mail,
    title: 'E-mail',
    lines: ['mytec.odonto@outlook.com'],
    action: { label: 'Enviar E-mail', href: 'mailto:mytec.odonto@outlook.com' },
  },
  {
    icon: Clock,
    title: 'Horário de Atendimento',
    lines: ['Seg–Sex: 08h às 18h', 'Sábado: 08h às 12h', 'Emergências: 24h'],
    action: null,
  },
];

export default function ContactSection() {
  return (
    <section id="contato" className="py-20 lg:py-28 bg-white">
      <div className="container">
        {/* Header */}
        <div className="text-center mb-14">
          <div className="inline-flex items-center gap-2 bg-blue-50 text-[#1A3A6B] rounded-full px-4 py-1.5 mb-4 text-sm font-semibold">
            <MapPin size={14} />
            Nossa Localização
          </div>
          <h2 className="text-3xl lg:text-4xl font-black text-gray-900 mb-4">
            Venha nos visitar ou{' '}
            <span className="text-[#1A3A6B]">agende uma visita técnica</span>
          </h2>
          <p className="text-gray-500 max-w-xl mx-auto">
            Estamos em São Luís, MA, mas atendemos todo o território nacional com equipe técnica especializada.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-10 items-start">
          {/* Map embed */}
          <div className="rounded-2xl overflow-hidden shadow-xl border border-gray-100 h-[400px]">
            <iframe
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3986.3!2d-44.2765!3d-2.5297!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x7f68f7c4a4b4b4b%3A0x0!2sRua+Qu%C3%A9ops%2C+12+-+Rena%C3%A7en%C3%A7a%2C+S%C3%A3o+Lu%C3%ADs+-+MA%2C+65075-800!5e0!3m2!1spt-BR!2sbr!4v1234567890"
              width="100%"
              height="100%"
              style={{ border: 0 }}
              allowFullScreen
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
              title="Localização My Tec. Odonto Soluções"
            />
          </div>

          {/* Contact cards */}
          <div className="grid sm:grid-cols-2 gap-4">
            {contactInfo.map(({ icon: Icon, title, lines, action }) => (
              <div key={title} className="bg-gray-50 rounded-2xl border border-gray-100 p-5 hover:border-[#1A3A6B]/20 hover:bg-blue-50/30 transition-all">
                <div className="w-10 h-10 bg-[#1A3A6B] rounded-xl flex items-center justify-center mb-4">
                  <Icon size={18} className="text-white" />
                </div>
                <h3 className="font-bold text-gray-800 mb-2">{title}</h3>
                {lines.map(line => (
                  <p key={line} className="text-gray-600 text-sm">{line}</p>
                ))}
                {action && (
                  <a
                    href={action.href}
                    target={action.href.startsWith('http') ? '_blank' : undefined}
                    rel={action.href.startsWith('http') ? 'noopener noreferrer' : undefined}
                    className="inline-flex items-center gap-1.5 text-[#1A3A6B] font-semibold text-sm mt-3 hover:text-[#10B981] transition-colors"
                  >
                    {action.label}
                    <ExternalLink size={13} />
                  </a>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* WhatsApp CTA banner */}
        <div className="mt-12 bg-gradient-to-r from-[#1A3A6B] to-[#0D1B3E] rounded-2xl p-8 flex flex-col sm:flex-row items-center justify-between gap-6">
          <div>
            <h3 className="text-white font-bold text-xl mb-1">Precisa de atendimento urgente?</h3>
            <p className="text-blue-200 text-sm">Nossa equipe técnica está disponível para emergências 24 horas.</p>
          </div>
          <a
            href="https://wa.me/5598981905646?text=Olá! Preciso de atendimento técnico urgente."
            target="_blank"
            rel="noopener noreferrer"
            className="flex-shrink-0 flex items-center gap-2.5 bg-[#25D366] hover:bg-[#1fba59] text-white font-bold px-6 py-3 rounded-xl transition-colors whatsapp-pulse text-sm"
          >
            <svg viewBox="0 0 24 24" className="w-5 h-5 fill-current"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
            Atendimento de Emergência
          </a>
        </div>
      </div>
    </section>
  );
}
