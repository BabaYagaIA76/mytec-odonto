/**
 * HeroSection — My Tec. Odonto Soluções
 * Seção principal com imagem de fundo, headline e CTAs
 */

import { ArrowRight, Search, CheckCircle2, Star } from 'lucide-react';
import { Button } from '@/components/ui/button';

const CDN = 'https://d2xsxph8kpxj0f.cloudfront.net/310519663421337620/KxGQz48AK3ognB3Cs5eo6C';

const stats = [
  { value: '+5.000', label: 'Peças vendidas' },
  { value: '+150', label: 'Consultórios atendidos' },
  { value: '+150', label: 'Contratos ativos' },
  { value: '98%', label: 'Clientes satisfeitos' },
];

export default function HeroSection() {
  const scrollTo = (id: string) => {
    document.querySelector(id)?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section className="relative min-h-screen flex items-center overflow-hidden">
      {/* Background Image */}
      <div className="absolute inset-0">
        <img
          src={`${CDN}/hero-banner-AookkaGL57B72D3WVjjHrj.webp`}
          alt="Técnico realizando manutenção em autoclave odontológica"
          className="w-full h-full object-cover"
        />
        {/* Gradient overlay — dark on left for text readability */}
        <div className="absolute inset-0 bg-gradient-to-r from-[#0D1B3E]/90 via-[#1A3A6B]/75 to-[#1A3A6B]/30" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#0D1B3E]/60 via-transparent to-transparent" />
      </div>

      {/* Content */}
      <div className="relative container pt-24 pb-16 lg:pt-32 lg:pb-24">
        <div className="max-w-2xl">
          {/* Badge */}
          <div className="inline-flex items-center gap-2 bg-white/10 backdrop-blur-sm border border-white/20 rounded-full px-4 py-1.5 mb-6">
            <span className="w-2 h-2 bg-[#10B981] rounded-full animate-pulse" />
            <span className="text-white/90 text-sm font-medium">Tecnologia em Odontologia desde 2019</span>
          </div>

          {/* Headline */}
          <h1 className="text-white font-black leading-tight mb-4" style={{ fontSize: 'clamp(2.2rem, 5vw, 3.5rem)' }}>
            Soluções completas para seu{' '}
            <span className="text-[#10B981]">consultório e  sua clínica</span>
          </h1>

          <p className="text-white/80 text-lg leading-relaxed mb-8 max-w-xl">
            Peças originais, aluguel de equipamentos de última geração e contratos de manutenção preventiva.
            Tudo que seu consultório precisa em um só lugar.
          </p>

          {/* Trust indicators */}
          <div className="flex flex-wrap gap-3 mb-8">
            {['Peças originais e compatíveis', 'Entrega express para todo Brasil', 'Garantia de 90 dias'].map(item => (
              <div key={item} className="flex items-center gap-1.5 text-white/90 text-sm">
                <CheckCircle2 size={15} className="text-[#10B981] flex-shrink-0" />
                <span>{item}</span>
              </div>
            ))}
          </div>

          {/* CTAs */}
          <div className="flex flex-wrap gap-3">
            <Button
              onClick={() => scrollTo('#catalogo')}
              className="bg-[#10B981] hover:bg-[#0ea572] text-white font-bold px-6 py-3 text-base gap-2 rounded-xl shadow-lg shadow-emerald-900/30"
            >
              <Search size={18} />
              Buscar Peças
            </Button>
            <Button
              onClick={() => scrollTo('#servicos')}
              variant="outline"
              className="border-white/40 text-white hover:bg-white/10 font-bold px-6 py-3 text-base gap-2 rounded-xl bg-white/5 backdrop-blur-sm"
            >
              Conhecer Serviços
              <ArrowRight size={18} />
            </Button>
          </div>
        </div>

        {/* Floating card — product highlight */}
        <div className="hidden lg:block absolute right-8 top-1/2 -translate-y-1/2 w-72">
          <div className="bg-white rounded-2xl shadow-2xl overflow-hidden">
            <div className="relative">
              <img
                src="/tecnico.png"
                alt="Técnico My Tec. Odonto"
                className="w-full h-44 object-cover"
              />
              <div className="absolute top-3 left-3 bg-[#10B981] text-white text-xs font-bold px-2.5 py-1 rounded-full">
                Disponível
              </div>
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
              <div className="absolute bottom-3 left-3 right-3">
                <p className="text-white font-bold text-sm">Nosso Técnico</p>
                <p className="text-white/80 text-xs">Expertise em manutenção</p>
              </div>
            </div>
            <div className="p-4">
              <p className="font-bold text-gray-800 text-sm">Autoclave 12L Classe B</p>
              <p className="text-gray-500 text-xs mt-0.5">Esterilização com secagem a vácuo</p>
              <div className="flex items-center justify-between mt-3">
                <div>
                  <p className="text-xs text-gray-400">A partir de</p>
                  <p className="text-[#1A3A6B] font-black text-lg">R$ 130<span className="text-sm font-medium">/dia</span></p>
                </div>
                <button
                  onClick={() => scrollTo('#aluguel')}
                  className="bg-[#1A3A6B] text-white text-xs font-bold px-3 py-2 rounded-lg hover:bg-[#152f58] transition-colors"
                >
                  Simular
                </button>
              </div>
            </div>
          </div>

          {/* Mini stats card */}
          <div className="mt-3 bg-white/10 backdrop-blur-md border border-white/20 rounded-xl p-3 flex items-center gap-3">
            <div className="w-10 h-10 bg-[#10B981] rounded-lg flex items-center justify-center flex-shrink-0">
              <Star size={18} className="text-white fill-white" />
            </div>
            <div>
              <p className="text-white font-bold text-sm">+500 consultórios</p>
              <p className="text-white/70 text-xs">atendidos em todo Brasil</p>
            </div>
          </div>
        </div>
      </div>

      {/* Stats bar */}
      <div className="absolute bottom-0 left-0 right-0 bg-[#1A3A6B]/80 backdrop-blur-md border-t border-white/10">
        <div className="container">
          <div className="grid grid-cols-2 lg:grid-cols-4 divide-x divide-white/10">
            {stats.map(stat => (
              <div key={stat.label} className="py-4 px-4 text-center">
                <p className="text-white font-black text-2xl" style={{ fontFamily: 'Barlow Condensed, sans-serif' }}>{stat.value}</p>
                <p className="text-white/60 text-xs mt-0.5">{stat.label}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
