/**
 * MaintenanceSection — My Tec. Odonto Soluções
 * Planos de manutenção preventiva e formulário de solicitação
 */

import { useState } from 'react';
import { Wrench, CheckCircle, Star, Send, User, Building2, Phone, Mail, ClipboardList } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { toast } from 'sonner';

const plans = [
  {
    name: 'Plano Preventivo',
    price: 'R$ 389',
    period: '/mês',
    highlight: false,
    features: [
      '1 visita técnica mensal',
      'Limpeza e calibração',
      'Relatório técnico',
      '10% desconto em peças',
      'Atendimento emergencial',
    ],
    cta: 'Contratar',
    color: 'border-gray-200',
    btnColor: 'bg-[#1A3A6B] hover:bg-[#152f58] text-white',
  },
  {
    name: 'Plano Completo',
    price: 'R$ 749.99',
    period: '/mês',
    highlight: true,
    features: [
      '2 visitas técnicas mensais',
      'Manutenção preventiva completa',
      'Troca de filtros e vedantes',
      '20% desconto em peças',
      'Atendimento emergencial 24h',
    ],
    cta: 'Contratar Agora',
    color: 'border-[#1A3A6B]',
    btnColor: 'bg-[#10B981] hover:bg-[#0ea572] text-white',
  },
  {
    name: 'Plano Clínica',
    price: 'Sob consulta',
    period: '',
    highlight: false,
    features: [
      'Visitas ilimitadas',
      'Todos os equipamentos',
      'Gestão de estoque de peças',
      '30% desconto em peças',
      'Equipamento reserva incluso',
    ],
    cta: 'Solicitar Proposta',
    color: 'border-gray-200',
    btnColor: 'bg-[#1A3A6B] hover:bg-[#152f58] text-white',
  },
];

export default function MaintenanceSection() {
  const [form, setForm] = useState({ name: '', clinic: '', phone: '', email: '', equipment: '' });
  const [sending, setSending] = useState(false);

  const handlePlan = (planName: string) => {
    const msg = encodeURIComponent(
      `Olá! Tenho interesse no *${planName}* de manutenção preventiva.\n\nPoderia me passar mais informações e iniciar o processo de contratação? Obrigado!`
    );
    window.open(`https://wa.me/5598981905646?text=${msg}`, '_blank');
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name || !form.phone) {
      toast.error('Preencha pelo menos seu nome e WhatsApp.');
      return;
    }
    setSending(true);
    const msg = encodeURIComponent(
      `*Solicitação de Avaliação Técnica*\n\n` +
      `Nome: ${form.name}\n` +
      `Clínica: ${form.clinic || 'Não informado'}\n` +
      `WhatsApp: ${form.phone}\n` +
      `E-mail: ${form.email || 'Não informado'}\n` +
      `Equipamentos: ${form.equipment || 'Não informado'}\n\n` +
      `Aguardo contato para agendamento. Obrigado!`
    );
    setTimeout(() => {
      window.open(`https://wa.me/5598981905646?text=${msg}`, '_blank');
      setSending(false);
      setForm({ name: '', clinic: '', phone: '', email: '', equipment: '' });
      toast.success('Solicitação enviada! Nossa equipe entrará em contato em breve.');
    }, 800);
  };

  return (
    <section id="manutencao" className="py-20 lg:py-28 bg-gray-50">
      <div className="container">
        {/* Header */}
        <div className="text-center mb-14">
          <div className="inline-flex items-center gap-2 bg-blue-50 text-[#1A3A6B] rounded-full px-4 py-1.5 mb-4 text-sm font-semibold">
            <Wrench size={14} />
            Contratos de Manutenção
          </div>
          <h2 className="text-3xl lg:text-4xl font-black text-gray-900 mb-4">
            Prevenção programada para evitar{' '}
            <span className="text-[#1A3A6B]">paradas inesperadas</span>
          </h2>
          <p className="text-gray-500 max-w-xl mx-auto">
            Prolongue a vida útil dos seus equipamentos com visitas técnicas periódicas e manutenção preventiva especializada.
          </p>
        </div>

        {/* Plans */}
        <div className="grid md:grid-cols-3 gap-6 mb-16">
          {plans.map(plan => (
            <div
              key={plan.name}
              className={`relative bg-white rounded-2xl border-2 ${plan.color} p-6 shadow-sm flex flex-col ${plan.highlight ? 'shadow-xl' : ''}`}
            >
              {plan.highlight && (
                <div className="absolute -top-3.5 left-1/2 -translate-x-1/2 flex items-center gap-1.5 bg-[#1A3A6B] text-white text-xs font-bold px-4 py-1.5 rounded-full shadow">
                  <Star size={11} className="fill-white" />
                  Mais Popular
                </div>
              )}

              <div className="mb-5">
                <h3 className="font-bold text-gray-900 text-lg mb-2">{plan.name}</h3>
                <div className="flex items-end gap-1">
                  <span className="text-3xl font-black text-[#1A3A6B]" style={{ fontFamily: 'Barlow Condensed, sans-serif' }}>{plan.price}</span>
                  {plan.period && <span className="text-gray-500 text-sm mb-1">{plan.period}</span>}
                </div>
              </div>

              <ul className="space-y-3 mb-6 flex-1">
                {plan.features.map(f => (
                  <li key={f} className="flex items-start gap-2.5 text-sm text-gray-600">
                    <CheckCircle size={15} className="text-[#10B981] flex-shrink-0 mt-0.5" />
                    {f}
                  </li>
                ))}
              </ul>

              <Button
                onClick={() => handlePlan(plan.name)}
                className={`w-full ${plan.btnColor} font-bold rounded-xl`}
              >
                {plan.cta}
              </Button>
            </div>
          ))}
        </div>

        {/* Request form */}
        <div className="max-w-2xl mx-auto">
          <div className="bg-white rounded-2xl shadow-lg border border-gray-100 overflow-hidden">
            <div className="bg-[#1A3A6B] p-6">
              <h3 className="text-white font-bold text-xl mb-1">Solicite uma Avaliação Técnica</h3>
              <p className="text-blue-200 text-sm">Nossa equipe entrará em contato em até 2 horas úteis</p>
            </div>
            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              <div className="grid sm:grid-cols-2 gap-4">
                <div className="relative">
                  <User size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                  <Input
                    value={form.name}
                    onChange={e => setForm(p => ({ ...p, name: e.target.value }))}
                    placeholder="Nome completo *"
                    className="pl-9 border-gray-200 focus:border-[#1A3A6B] rounded-xl"
                    required
                  />
                </div>
                <div className="relative">
                  <Building2 size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                  <Input
                    value={form.clinic}
                    onChange={e => setForm(p => ({ ...p, clinic: e.target.value }))}
                    placeholder="Nome da Clínica"
                    className="pl-9 border-gray-200 focus:border-[#1A3A6B] rounded-xl"
                  />
                </div>
                <div className="relative">
                  <Phone size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                  <Input
                    value={form.phone}
                    onChange={e => setForm(p => ({ ...p, phone: e.target.value }))}
                    placeholder="WhatsApp *"
                    type="tel"
                    className="pl-9 border-gray-200 focus:border-[#1A3A6B] rounded-xl"
                    required
                  />
                </div>
                <div className="relative">
                  <Mail size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                  <Input
                    value={form.email}
                    onChange={e => setForm(p => ({ ...p, email: e.target.value }))}
                    placeholder="E-mail"
                    type="email"
                    className="pl-9 border-gray-200 focus:border-[#1A3A6B] rounded-xl"
                  />
                </div>
              </div>
              <div className="relative">
                <ClipboardList size={16} className="absolute left-3 top-3.5 text-gray-400" />
                <textarea
                  value={form.equipment}
                  onChange={e => setForm(p => ({ ...p, equipment: e.target.value }))}
                  placeholder="Liste os equipamentos que precisam de manutenção (marca, modelo, problema)..."
                  className="w-full pl-9 pr-3 py-3 border border-gray-200 rounded-xl text-sm focus:outline-none focus:border-[#1A3A6B] resize-none h-24"
                />
              </div>
              <Button
                type="submit"
                disabled={sending}
                className="w-full bg-[#1A3A6B] hover:bg-[#152f58] text-white font-bold py-3 text-base gap-2 rounded-xl"
              >
                {sending ? (
                  <span className="flex items-center gap-2">
                    <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    Enviando...
                  </span>
                ) : (
                  <>
                    <Send size={18} />
                    Enviar Solicitação
                  </>
                )}
              </Button>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
}
