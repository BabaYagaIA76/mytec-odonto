/**
 * RentalSection — My Tec. Odonto Soluções
 * Aluguel de equipamentos com calculadora de custo médio
 */

import { useState, useMemo } from 'react';
import { CalendarCheck, CheckCircle, Calculator, TrendingDown, Zap, Clock, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { rentalEquipments } from '@/lib/products';

const discountTiers = [
  { days: 7, pct: 5 },
  { days: 15, pct: 10 },
  { days: 30, pct: 15 },
  { days: 60, pct: 20 },
  { days: 90, pct: 25 },
];

const useCases = [
  {
    icon: Zap,
    title: 'Substituição Emergencial',
    desc: 'Equipamento quebrou? Alugue enquanto conserta o seu.',
    color: 'text-amber-500',
    bg: 'bg-amber-50',
  },
  {
    icon: TrendingDown,
    title: 'Aumento Temporário',
    desc: 'Mais pacientes? Alugue equipamentos adicionais por curto prazo.',
    color: 'text-blue-500',
    bg: 'bg-blue-50',
  },
  {
    icon: Clock,
    title: 'Teste antes da Compra',
    desc: 'Experimente o equipamento por 30 dias antes de investir.',
    color: 'text-emerald-500',
    bg: 'bg-emerald-50',
  },
];

export default function RentalSection() {
  const [selectedEquipId, setSelectedEquipId] = useState(rentalEquipments[0].id);
  const [days, setDays] = useState(30);

  const selectedEquip = rentalEquipments.find(e => e.id === selectedEquipId) || rentalEquipments[0];

  const { dailyRate, discount, total, totalWithDiscount } = useMemo(() => {
    const rate = selectedEquip.dailyRate;
    const gross = rate * days;
    const tier = [...discountTiers].reverse().find(t => days >= t.days);
    const pct = tier ? tier.pct : 0;
    const discountAmt = gross * (pct / 100);
    return {
      dailyRate: rate,
      discount: pct,
      total: gross,
      totalWithDiscount: gross - discountAmt,
    };
  }, [selectedEquip, days]);

  const handleReserve = () => {
    const msg = encodeURIComponent(
      `Olá! Gostaria de reservar o seguinte equipamento:\n\n` +
      `*${selectedEquip.name}*\n` +
      `Período: ${days} dias\n` +
      `Diária: R$ ${dailyRate.toFixed(2)}\n` +
      `Desconto: ${discount}%\n` +
      `*Total estimado: R$ ${totalWithDiscount.toFixed(2)}*\n\n` +
      `Aguardo confirmação de disponibilidade. Obrigado!`
    );
    window.open(`https://wa.me/5598981905646?text=${msg}`, '_blank');
  };

  return (
    <section id="aluguel" className="py-20 lg:py-28 bg-[#0D1B3E]">
      <div className="container">
        {/* Header */}
        <div className="text-center mb-14">
          <div className="inline-flex items-center gap-2 bg-white/10 text-white rounded-full px-4 py-1.5 mb-4 text-sm font-semibold border border-white/20">
            <CalendarCheck size={14} />
            Aluguel de Equipamentos
          </div>
          <h2 className="text-3xl lg:text-4xl font-black text-white mb-4">
            Solução inteligente para manter seu{' '}
            <span className="text-[#10B981]">consultório operacional</span>
          </h2>
          <p className="text-white/60 max-w-xl mx-auto">
            Sem investimento inicial alto. Contratos flexíveis com entrega e instalação inclusas.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-10 items-start">
          {/* Left — Use cases + Equipment cards */}
          <div className="space-y-6">
            {/* Use cases */}
            <div className="space-y-3">
              {useCases.map(({ icon: Icon, title, desc, color, bg }) => (
                <div key={title} className="flex items-start gap-4 bg-white/5 border border-white/10 rounded-xl p-4">
                  <div className={`w-10 h-10 ${bg} rounded-lg flex items-center justify-center flex-shrink-0`}>
                    <Icon size={20} className={color} />
                  </div>
                  <div>
                    <p className="text-white font-bold text-sm">{title}</p>
                    <p className="text-white/60 text-xs mt-0.5">{desc}</p>
                  </div>
                </div>
              ))}
            </div>

            {/* Equipment selection cards */}
            <div>
              <p className="text-white/70 text-sm font-semibold mb-3 uppercase tracking-wider">Equipamentos disponíveis</p>
              <div className="grid grid-cols-2 gap-3">
                {rentalEquipments.map(equip => (
                  <button
                    key={equip.id}
                    onClick={() => setSelectedEquipId(equip.id)}
                    className={`relative rounded-xl overflow-hidden border-2 transition-all duration-200 text-left ${
                      selectedEquipId === equip.id
                        ? 'border-[#10B981] shadow-lg shadow-emerald-900/30'
                        : 'border-white/10 hover:border-white/30'
                    }`}
                  >
                    <img
                      src={equip.image}
                      alt={equip.name}
                      className="w-full h-24 object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent" />
                    <div className="absolute bottom-2 left-2 right-2">
                      <p className="text-white font-bold text-xs leading-tight">{equip.name}</p>
                      <p className="text-[#10B981] font-black text-sm">R$ {equip.dailyRate}/dia</p>
                    </div>
                    {selectedEquipId === equip.id && (
                      <div className="absolute top-2 right-2 w-5 h-5 bg-[#10B981] rounded-full flex items-center justify-center">
                        <CheckCircle size={12} className="text-white fill-white" />
                      </div>
                    )}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Right — Calculator */}
          <div className="bg-white rounded-2xl shadow-2xl overflow-hidden">
            <div className="bg-[#1A3A6B] p-5">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-white/10 rounded-xl flex items-center justify-center">
                  <Calculator size={20} className="text-white" />
                </div>
                <div>
                  <h3 className="text-white font-bold">Simule seu Aluguel</h3>
                  <p className="text-blue-200 text-xs">Cálculo com desconto progressivo</p>
                </div>
              </div>
            </div>

            <div className="p-6 space-y-5">
              {/* Selected equipment */}
              <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-xl border border-gray-100">
                <img
                  src={selectedEquip.image}
                  alt={selectedEquip.name}
                  className="w-12 h-12 object-cover rounded-lg"
                />
                <div>
                  <p className="font-bold text-gray-800 text-sm">{selectedEquip.name}</p>
                  <p className="text-gray-500 text-xs">{selectedEquip.description}</p>
                </div>
              </div>

              {/* Equipment selector */}
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">Equipamento</label>
                <select
                  value={selectedEquipId}
                  onChange={e => setSelectedEquipId(e.target.value)}
                  className="w-full border border-gray-200 rounded-xl px-3 py-2.5 text-sm text-gray-700 focus:outline-none focus:border-[#1A3A6B] bg-white"
                >
                  {rentalEquipments.map(e => (
                    <option key={e.id} value={e.id}>{e.name} — R$ {e.dailyRate}/dia</option>
                  ))}
                </select>
              </div>

              {/* Days slider */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <label className="text-sm font-semibold text-gray-700">Período de aluguel</label>
                  <span className="text-[#1A3A6B] font-black text-lg">{days} dias</span>
                </div>
                <input
                  type="range"
                  min={1}
                  max={90}
                  value={days}
                  onChange={e => setDays(Number(e.target.value))}
                  className="w-full h-2 bg-gray-200 rounded-full appearance-none cursor-pointer"
                  style={{
                    background: `linear-gradient(to right, #1A3A6B ${(days / 90) * 100}%, #e5e7eb ${(days / 90) * 100}%)`
                  }}
                />
                <div className="flex justify-between text-xs text-gray-400 mt-1">
                  <span>1 dia</span>
                  <span>90 dias</span>
                </div>
              </div>

              {/* Discount tiers */}
              <div className="flex gap-1.5 flex-wrap">
                {discountTiers.map(t => (
                  <span
                    key={t.days}
                    className={`text-xs px-2.5 py-1 rounded-full font-medium transition-all ${
                      days >= t.days
                        ? 'bg-[#10B981] text-white'
                        : 'bg-gray-100 text-gray-400'
                    }`}
                  >
                    {t.days}d = {t.pct}% off
                  </span>
                ))}
              </div>

              {/* Result */}
              <div className="bg-gradient-to-br from-blue-50 to-emerald-50 rounded-xl p-4 border border-blue-100">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-gray-600 text-sm">Diária:</span>
                  <span className="font-bold text-gray-800">R$ {dailyRate.toFixed(2)}</span>
                </div>
                {discount > 0 && (
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-gray-600 text-sm">Subtotal ({days} dias):</span>
                    <span className="text-gray-400 line-through text-sm">R$ {total.toFixed(2)}</span>
                  </div>
                )}
                <div className="flex items-center justify-between mb-2">
                  <span className="text-gray-600 text-sm">Desconto:</span>
                  <span className="text-[#10B981] font-bold">{discount}%</span>
                </div>
                <div className="border-t border-blue-100 pt-2 mt-2 flex items-center justify-between">
                  <span className="font-bold text-gray-800">Total estimado:</span>
                  <span className="text-[#1A3A6B] font-black text-2xl">R$ {totalWithDiscount.toFixed(2)}</span>
                </div>
              </div>

              <p className="text-xs text-gray-400 text-center">
                * Entrega e instalação inclusas. Valores sujeitos a confirmação de disponibilidade.
              </p>

              {/* Features */}
              <div className="grid grid-cols-2 gap-2">
                {selectedEquip.features.map(f => (
                  <div key={f} className="flex items-center gap-1.5 text-xs text-gray-600">
                    <CheckCircle size={12} className="text-[#10B981] flex-shrink-0" />
                    {f}
                  </div>
                ))}
              </div>

              <Button
                onClick={handleReserve}
                className="w-full bg-[#25D366] hover:bg-[#1fba59] text-white font-bold py-3 text-base gap-2 rounded-xl"
              >
                <svg viewBox="0 0 24 24" className="w-5 h-5 fill-current"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
                Reservar via WhatsApp
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
