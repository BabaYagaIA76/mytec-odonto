/**
 * ServicesSection — My Tec. Odonto Soluções
 * Três serviços principais: Peças, Aluguel e Manutenção com imagem de modelo
 */

import { Package, Wrench, CalendarCheck, ArrowRight, CheckCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';

const CDN = 'https://d2xsxph8kpxj0f.cloudfront.net/310519663421337620/KxGQz48AK3ognB3Cs5eo6C';

const services = [
  {
    icon: Package,
    title: 'Venda de Peças',
    description: 'Mais de 5.000 itens em estoque para autoclaves, compressores, cadeiras e equipamentos odontológicos das principais marcas.',
    features: ['Peças originais e compatíveis', 'Envio para todo Brasil', 'Garantia de 90 dias', 'Suporte técnico incluso'],
    cta: 'Buscar Peças',
    ctaHref: '#catalogo',
    color: 'blue',
    badge: null,
  },
  {
    icon: CalendarCheck,
    title: 'Aluguel de Equipamentos',
    description: 'Solução ideal para substituição temporária, aumento da capacidade ou teste antes da compra. Contratos flexíveis.',
    features: ['Contratos flexíveis (diária/mensal)', 'Manutenção inclusa', 'Entrega e instalação', 'Suporte 24h'],
    cta: 'Simular Aluguel',
    ctaHref: '#aluguel',
    color: 'emerald',
    badge: 'Popular',
  },
  {
    icon: Wrench,
    title: 'Contratos de Manutenção',
    description: 'Prevenção é melhor que reparo. Planos mensais que garantem a longevidade dos seus equipamentos.',
    features: ['Visitas periódicas programadas', 'Desconto em peças de reposição', 'Atendimento prioritário', 'Relatório técnico'],
    cta: 'Solicitar Proposta',
    ctaHref: '#manutencao',
    color: 'blue',
    badge: null,
  },
];

const colorMap = {
  blue: {
    iconBg: 'bg-blue-50',
    iconColor: 'text-[#1A3A6B]',
    border: 'border-blue-100 hover:border-[#1A3A6B]/30',
    btn: 'bg-[#1A3A6B] hover:bg-[#152f58] text-white',
    check: 'text-[#1A3A6B]',
  },
  emerald: {
    iconBg: 'bg-emerald-50',
    iconColor: 'text-[#10B981]',
    border: 'border-emerald-200 hover:border-[#10B981]/50',
    btn: 'bg-[#10B981] hover:bg-[#0ea572] text-white',
    check: 'text-[#10B981]',
  },
};

export default function ServicesSection() {
  const scrollTo = (href: string) => {
    document.querySelector(href)?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section id="servicos" className="py-20 lg:py-28 bg-gray-50">
      <div className="container">
        {/* Header */}
        <div className="text-center mb-14">
          <div className="inline-flex items-center gap-2 bg-blue-50 text-[#1A3A6B] rounded-full px-4 py-1.5 mb-4 text-sm font-semibold">
            <Wrench size={14} />
            Nossos Serviços
          </div>
          <h2 className="text-3xl lg:text-4xl font-black text-gray-900 mb-4">
            Três soluções integradas para manter seu{' '}
            <span className="text-[#1A3A6B]">consultório sempre em funcionamento</span>
          </h2>
          <p className="text-gray-500 max-w-xl mx-auto">
            Da peça de reposição ao contrato de manutenção preventiva, somos o parceiro técnico completo do seu consultório.
          </p>
        </div>

        {/* Image + Cards Layout */}
        <div className="grid lg:grid-cols-2 gap-8 items-start">
          {/* Image */}
          <div className="hidden lg:block">
            <img
              src={`${CDN}/CMT2_6d3fe2eb.png`}
              alt="Técnico My Tec. Odonto em ação"
              className="w-full h-auto rounded-2xl shadow-lg object-cover"
            />
          </div>

          {/* Cards */}
          <div className="grid gap-6">
            {services.map(service => {
              const colors = colorMap[service.color as keyof typeof colorMap];
              const Icon = service.icon;
              return (
                <div
                  key={service.title}
                  className={`relative bg-white rounded-2xl border-2 ${colors.border} p-6 shadow-sm hover:shadow-lg transition-all duration-300 flex flex-col`}
                >
                  {service.badge && (
                    <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-[#10B981] text-white text-xs font-bold px-4 py-1 rounded-full shadow">
                      {service.badge}
                    </div>
                  )}

                  <div className={`w-12 h-12 ${colors.iconBg} rounded-xl flex items-center justify-center mb-5`}>
                    <Icon size={24} className={colors.iconColor} />
                  </div>

                  <h3 className="text-xl font-bold text-gray-900 mb-3">{service.title}</h3>
                  <p className="text-gray-500 text-sm leading-relaxed mb-5">{service.description}</p>

                  <ul className="space-y-2.5 mb-6 flex-1">
                    {service.features.map(f => (
                      <li key={f} className="flex items-start gap-2 text-sm text-gray-600">
                        <CheckCircle size={15} className={`${colors.check} flex-shrink-0 mt-0.5`} />
                        {f}
                      </li>
                    ))}
                  </ul>

                  <Button
                    onClick={() => scrollTo(service.ctaHref)}
                    className={`w-full ${colors.btn} font-bold gap-2 rounded-xl`}
                  >
                    {service.cta}
                    <ArrowRight size={16} />
                  </Button>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}
