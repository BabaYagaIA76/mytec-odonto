/**
 * TestimonialsSection — My Tec. Odonto Soluções
 * Depoimentos de clientes e marcas parceiras
 */

import { Star, Quote } from 'lucide-react';

const testimonials = [
  {
    name: 'Maria Laryssa',
    role: 'Gerente de Clínica',
    clinic: 'Clínica Odontológica, São Luís/MA',
    text: 'Excelente atendimento, serviço de qualidade e pontualidade. A My Tec. Odonto é realmente confiável e profissional. Recomendo para todos os consultórios!',
    rating: 5,
    avatar: 'ML',
  },
  {
    name: 'Isabela Souza',
    role: 'Proprietária de Clínica',
    clinic: 'Consultório Odontológico, São Luís/MA',
    text: 'Gerson e Isaias foram muito honestos em relação aos meus equipamentos, além de serem muito atenciosos e respeitosos. Certeza que valerá caso haja necessidade!',
    rating: 5,
    avatar: 'IS',
  },
  {
    name: 'Silvia Maria Carvalho',
    role: 'Cirurgiã-Dentista',
    clinic: 'Clínica Odonto Carvalho, São Luís/MA',
    text: 'Serviço técnico de excelência! A equipe da My Tec. é muito profissional e dedicada. Meus equipamentos funcionam perfeitamente desde que contratei os serviços deles.',
    rating: 5,
    avatar: 'SC',
  },
];

const brands = [
  'Cristófoli', 'Dabi Atlante', 'Gnatus', 'NSK', 'AirZap', 'Saevo', 'Kavo', 'Bioart',
];

export default function TestimonialsSection() {
  return (
    <section className="py-20 bg-white border-t border-gray-100">
      <div className="container">
        {/* Testimonials */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 bg-blue-50 text-[#1A3A6B] rounded-full px-4 py-1.5 mb-4 text-sm font-semibold">
            <Star size={14} className="fill-[#1A3A6B]" />
            Depoimentos
          </div>
          <h2 className="text-3xl font-black text-gray-900 mb-3">
            O que nossos clientes dizem
          </h2>
          <p className="text-gray-500 max-w-md mx-auto text-sm">
            Classificação 5.0 ⭐ no Google. Mais de 500 consultórios confiam na My Tec. Odonto para manter seus equipamentos funcionando.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-6 mb-16">
          {testimonials.map(t => (
            <div key={t.name} className="bg-gray-50 rounded-2xl border border-gray-100 p-6 relative">
              <Quote size={28} className="text-[#1A3A6B]/10 absolute top-4 right-4" />
              <div className="flex gap-0.5 mb-4">
                {Array.from({ length: t.rating }).map((_, i) => (
                  <Star key={i} size={14} className="text-amber-400 fill-amber-400" />
                ))}
              </div>
              <p className="text-gray-600 text-sm leading-relaxed mb-5 italic">"{t.text}"</p>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-[#1A3A6B] rounded-full flex items-center justify-center flex-shrink-0">
                  <span className="text-white font-bold text-sm">{t.avatar}</span>
                </div>
                <div>
                  <p className="font-bold text-gray-800 text-sm">{t.name}</p>
                  <p className="text-gray-500 text-xs">{t.role}</p>
                  <p className="text-[#10B981] text-xs font-medium">{t.clinic}</p>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Brand logos */}
        <div className="border-t border-gray-100 pt-10">
          <p className="text-center text-gray-400 text-sm font-medium mb-6 uppercase tracking-wider">
            Marcas que atendemos
          </p>
          <div className="flex flex-wrap justify-center gap-3">
            {brands.map(brand => (
              <div
                key={brand}
                className="px-5 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-gray-600 font-semibold text-sm hover:border-[#1A3A6B]/30 hover:text-[#1A3A6B] hover:bg-blue-50 transition-all"
              >
                {brand}
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
